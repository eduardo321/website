// JavaScript Document
$('#slider').cycle({
	
fx: 			'scrollHorz' ,
next: 			'#next ',
prev:			'#prev ',
timeout:        0,
pause:          1
	
	});